# AI Kids Flying Studio

यह GitHub Pages पर चलने वाला शुरुआती PWA डेमो है।

## चलाने का तरीका
1. ZIP को Extract करें।
2. GitHub में नया repository बनाएँ।
3. ZIP के अंदर की सभी फाइलें repository के root में upload करें (`index.html`, `manifest.webmanifest`, `sw.js`)।
4. Settings → Pages → Deploy from a branch → `main` → `/ (root)` चुनें।
5. वेबसाइट खुलने पर Chrome के menu से **Add to Home screen / Install app** चुनें।

## अभी क्या काम करता है
- बच्चे और कमरे की फोटो अपलोड
- कमरे के ऊपर बच्चे की floating animation preview
- Canvas recording को WebM वीडियो के रूप में डाउनलोड करना

## जरूरी सीमा
यह अभी AI-generated video नहीं है। यह browser-based animation demo है। असली AI video generation (नई facial expressions, natural body motion, realistic flight) के लिए AI video provider की API और secure backend चाहिए। API key को `index.html` या public GitHub repository में न रखें।
